const mongoose = require('mongoose');


const itemSchema = new mongoose.Schema({
    target: String,
    school: String,
    studentName: Boolean,
    class: Boolean,
    section: Boolean,
    dob: Boolean,
    addmissionNo: Boolean,
    rollNo: Boolean,
    contactNo: Boolean,
    emeContactNo: Boolean,
    bloodGroup: Boolean,
    uploadPhoto: Boolean,
    studentUIDNumber: Boolean,
    modeOfTransportation: Boolean,
    designation: Boolean, 
    nameOfEmployee: Boolean,
    selectIdType: Boolean,
  });
  
  let Item = mongoose.model("item", itemSchema);

  module.exports = Item;