const mongoose = require("mongoose");

const itemSchema = new mongoose.Schema({
  target: String,
  school: String,
  studentName: Boolean,
  class: Boolean,
  section: Boolean,
  dob: Boolean,
  addmissionNo: Boolean,
  rollNo: Boolean,
  contactNo: Boolean,
  emeContactNo: Boolean,
  bloodGroup: Boolean,
  uploadPhoto: Boolean,
  studentUIDNumber: Boolean,
  modeOfTransportation: Boolean,
  designation: Boolean,
  nameOfEmployee: Boolean,
  selectIdType: Boolean,
});

exports.Item = mongoose.model("item", itemSchema);

const userSchema = new mongoose.Schema({
  target: String,
  school: String,
  studentName: String,
  class: String,
  section: String,
  dob: String,
  addmissionNo: String,
  rollNo: String,
  contactNo: String,
  emeContactNo: String,
  bloodGroup: String,
  uploadPhoto: String,
  studentUIDNumber: String,
  modeOfTransportation: String,
  designation: String,
  nameOfEmployee: String,
  selectIdType: String,
});

exports.userData = mongoose.model("userData", userSchema);
