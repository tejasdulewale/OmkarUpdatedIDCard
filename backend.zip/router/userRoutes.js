const userController = require('../controllers/userController');
const express = require('express')
const router = express.Router();

router.route("/:schoolName/:target").get(userController.showRegistrationForm);
router.route("/submit").post(userController.storeUserData);

module.exports = router;