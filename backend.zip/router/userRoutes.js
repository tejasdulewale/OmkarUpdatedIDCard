const userController = require('../controllers/userController');
const express = require('express')
const router = express.Router();

router.route("/:schoolName/:target").get(userController.showRegistrationForm);

module.exports = router;