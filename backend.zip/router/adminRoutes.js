const fieldDataController = require('../controllers/fieldDataController');
const express = require('express')
const router = express.Router();

router.route('/addFieldsToDB').post(fieldDataController.updateFieldData);
router.route('/getTargetData').post(fieldDataController.getFieldData);

module.exports = router;