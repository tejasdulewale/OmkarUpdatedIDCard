const express = require("express");
const app = express();
const path = require("path");
const staticDirectory = path.join(__dirname, "../public");
app.use(express.static(staticDirectory));

exports.showRegistrationForm = async (req, res, next)=>{
    res.status(200).sendFile(path.join(staticDirectory, "registration.html"));
}