const express = require("express");
const app = express();
const path = require("path");
const admin = require(path.join(__dirname, "../models/admin.js"));
const staticDirectory = path.join(__dirname, "../public");
app.use(express.static(staticDirectory));

exports.storeUserData = async (req, res, next) => {
  // Filter out properties with falsy values from req.body
  const filteredBody = Object.fromEntries(
    Object.entries(req.body).filter(([_, value]) => value)
  );

  // Create itemData object with target and filtered req.body
  const itemData = {
    ...filteredBody
  };

  console.log(itemData);

  // Create a new Item document using itemData
  const user = new admin.userData(itemData);

  // Save the user to the database
  await user.save({ validateBeforeSave: false });

  res.status(200).json({ success: true, message: "User data stored successfully" });
};

exports.showRegistrationForm = async (req, res, next) => {
  res.status(200).sendFile(path.join(staticDirectory, "registration.html"));
};

