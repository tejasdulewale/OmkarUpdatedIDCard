// const mongoose = require("mongoose");
const path = require("path");
const admin = require(path.join(__dirname, "../models/admin.js"));

exports.updateFieldData = async (req, res, next) => {
  try {
    const studentCounts = req.body;
    const result = await admin.Item.findOneAndReplace(
      { target: studentCounts.target }, // Find document with the target key
      studentCounts, // Replace with the new document
      { upsert: true } // Create a new document if not found
    );

    if (result) {
      res.status(200).json({
        status: "successful",
        message: "Updated",
      }); // Document found and replaced
    } else {
      res.status(200).json({
        status: "successful",
        message: "Saved",
      }); // Document not found, new document created
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).send("Server Error");
  }
  next();
};

exports.getFieldData = async (req, res, next) => {
  try {
    const { school, target } = req.body;

    // Query MongoDB using Mongoose
    const document = await admin.Item.findOne({
      school: school,
      target: target,
    });

    if (document) {
      // Document found
      console.log("Document found:", document);
      res.status(200).json(document);
    } else {
      // Document not found
      console.log("Document not found");
      res.status(404).json({ message: "Document not found" });
    }
  } catch (error) {
    // Error handling
    console.error("Error:", error);
    res.status(500).json({ message: "Server error" });
  }
  next();
};


