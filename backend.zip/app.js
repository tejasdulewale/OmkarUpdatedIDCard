const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const adminRoutes = require("./router/adminRoutes");
const userRoutes = require("./router/userRoutes");

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
const staticDirectory = path.join(__dirname, "public");
app.use(express.static(staticDirectory));

app.post("/", (req, res) => {
  res.sendFile(path.join(staticDirectory, "index.html"));
});

app.use('/v1', adminRoutes);
app.use('/v1', userRoutes);


//   app.get("/register/student", (req, res) => {
//     res.sendFile(path.join(staticDirectory, "registration.html"));
//   });

module.exports = app;