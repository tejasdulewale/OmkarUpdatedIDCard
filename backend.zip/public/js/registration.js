async function getTargetData(school, target) {
  try {
    const response = await fetch("/v1/getTargetData", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        school: school,
        target: target,
      }).toString(),
    });

    const data = await response.json();
    // console.log(data);
    return data;
  } catch (error) {
    console.error("Error:", error);
  }
}

async function main() {
  const fields = document.getElementsByClassName("dataField");
  const currentPath = window.location.pathname;
  const pathParts = currentPath.split("/");
  const school = pathParts[2];
  const target = pathParts[3];

  try {
    const data = await getTargetData(school, target);
    const filteredData = Object.entries(data).filter(
      ([key, value]) => value === true
    );
    const filteredDataObj = filteredData.reduce((obj, [key, value]) => {
      obj[key] = value;
      return obj;
    }, {});

    for (const element of fields) {
        element.style.display = "none";
    }

    for (const element of fields) {
        const customAttribute = element.getAttribute("data-custom-attribute");
        if (filteredDataObj.hasOwnProperty(customAttribute)) {
          element.style.display = "block";
        } else {
          element.style.display = "none";
        }
      }

    console.log(filteredDataObj);
  } catch (error) {
    console.error("Error:", error);
  }
}

main();
