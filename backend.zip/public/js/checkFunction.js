let tickButtons = document.querySelectorAll(".tick");
let studentCounts = {
  target: "",
  school: "",
  value1: false,
  value2: false,
  value3: false,
  value4: false,
  value5: false,
  value6: false,
  value7: false,
  value8: false,
  value9: false,
  value10: false,
  value11: false,
  value12: false,
  value13: false,
  value14: false,
  value15: false,
};



tickButtons.forEach((btn, index) => {
  btn.addEventListener("click", function () {
    if (studentCounts[`value${index + 1}`]) {
      btn.src = "../images/white.jpeg";
      studentCounts[`value${index + 1}`] = false;
    } else {
      btn.src = "../images/check.jpg";
      studentCounts[`value${index + 1}`] = true;
    }
  });
});

let genbtn = document.querySelector(".button");
genbtn.addEventListener("click", async () => {
  // Assigned demo value for school. This value should be dynamically added.
  studentCounts['school'] = "Sanjuba_High_School(CBSC)";


  studentCounts[`target`] = document.querySelector(
    'input[name="optradio"]:checked'
  ).value;
  let linkbox = document.querySelector(".genlink");
  const formData = new URLSearchParams();
  const newKeys = [
    "target",
    "school",
    "studentName",
    "class",
    "section",
    "dob",
    "addmissionNo",
    "rollNo",
    "contactNo",
    "emeContactNo",
    "bloodGroup",
    "uploadPhoto",
    "studentUIDNumber",
    "modeOfTransportation",
    "designation",
    "nameOfEmployee",
    "selectIdType",
  ];
  let i = 0;
  for (const [key, value] of Object.entries(studentCounts)) {
    formData.append(newKeys[i], value);
    i++;
  }
  try {
    const response = await fetch("/v1/addFieldsToDB", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: formData,
    });

    if (response.ok) {
      console.log("Object saved successfully");
    } else {
      console.error("Failed to save object:", response.statusText);
    }
  } catch (error) {
    console.error("Error occurred:", error);
  }
  //Todo: send selected fields to registration form
  //Todo: Actual link generation
  linkbox.innerHTML = `http://localhost:8888/v1/${studentCounts['school']}/${studentCounts['target']}`;
});
