let check_box_btn=document.querySelector(".student-check");
let btn=document.querySelector(".check_box_img")


let count=1;
check_box_btn.addEventListener("click" ,function(){
    if(count==1){
        btn.src="../images/check.jpeg"     
        count=0
    
    }else{
        btn.src="../images/white.jpeg"
        count=1
    }
});





let staff_check=document.querySelector(".staff_check");
let img_buttone=document.querySelector(".staff_check_box")


let click=1;
staff_check.addEventListener("click" ,function(){
    if(click==1){
        
        img_buttone.src="images/check.jpeg"     
        click=0
    
    }else{
       
        img_buttone.src="images/white.jpeg"
        
        click=1
}
});